import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'fs'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
	server: {
		host: '0.0.0.0',
		port: 5173,
		strictPort: true,
		https: {
			key: fs.readFileSync(path.resolve(__dirname, 'key.pem')),
			cert: fs.readFileSync(path.resolve(__dirname, 'cert.pem'))
		},
		proxy: {
			'/api': {
				target: 'http://192.168.56.2:3000',
				changeOrigin: true,
				secure: false, // Para permitir HTTP en el proxy
			},
		}
	},
	plugins: [react()],
})
