
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import './App.css'
import './Components/TIViews/TIViews.css'
import RHViews from './Components/RHViews/index';
import TIViews from './Components/TIViews'



function App() {

  

  return (
    <>
      <TIViews/>

    </>
  )
}

export default App;

